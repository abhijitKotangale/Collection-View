//
//  CustomCollectionViewCell.m
//  Collection View
//
//  Created by Abhijit Kotangale on 8/7/17.
//  Copyright © 2017 Abhijit Kotangale. All rights reserved.
//

#import "CustomCollectionViewCell.h"

@implementation CustomCollectionViewCell

@end
