//
//  ViewController.m
//  Collection View
//
//  Created by Abhijit Kotangale on 8/7/17.
//  Copyright © 2017 Abhijit Kotangale. All rights reserved.
//

#import "ViewController.h"
#import "CustomCollectionViewCell.h"

@interface ViewController (){
    NSMutableArray *arrImages;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrImages = [[NSMutableArray alloc]init];
    [arrImages addObject:@"1.jpg"];
    [arrImages addObject:@"2.jpg"];
    [arrImages addObject:@"3.jpg"];
    [arrImages addObject:@"4.jpg"];
    
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [_collectionView reloadData];

    // Do any additional setup after loading the view, typically from a nib.
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return arrImages.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CustomCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CustomCollectionViewCell" forIndexPath:indexPath];
    NSString *str = [arrImages objectAtIndex:indexPath.row];
    cell.imgView.image = [UIImage imageNamed:str];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
