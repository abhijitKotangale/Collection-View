//
//  AppDelegate.h
//  Collection View
//
//  Created by Abhijit Kotangale on 8/7/17.
//  Copyright © 2017 Abhijit Kotangale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

